chrome.commands.onCommand.addListener(async command => {
  const type = { 'toggle-picker': 'RASTA_TOGGLE', 'undo-last': 'RASTA_UNDO' }[command];
  if (!type) return;
  const [tab] = await chrome.tabs.query({active: true, lastFocusedWindow: true});
  if (!tab?.id) return;
  try { await chrome.tabs.sendMessage(tab.id, {type}, {frameId: 0}); } catch (_) { /* restricted page */ }
});
