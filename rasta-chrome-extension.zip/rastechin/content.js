(() => {
  if (window.__rastaLoaded) return;
  window.__rastaLoaded = true;
  const STYLE_ID = 'rasta-page-style';
  const MARK = 'data-rasta-aligned';
  const BLOCKS = 'p,li,blockquote,pre,h1,h2,h3,h4,h5,h6,td,th,dt,dd,figcaption,caption,summary,div,section,article,[contenteditable="true"],[role="textbox"]';
  let picking = false, hovered = null, host = null, label = null, doneButton = null, undoButton = null, count = 0, history = [];
  let lang = 'fa';
  const messages = {
    fa: {hover: 'روی یک متن بروید و کلیک کنید', select: 'انتخاب', restore: 'بازگردانی', align: 'راست‌چین', completed: n => `انجام شد · ${n} بخش فعال · برای ادامه کلیک کنید`, done: 'پایان ×', undo: 'واگرد ↶', undone: 'آخرین تغییر بازگردانده شد', empty: 'تغییری برای واگرد نیست'},
    en: {hover: 'Hover over a passage and click', select: 'Selected', restore: 'restore', align: 'right-align', completed: n => `Done · ${n} active section${n === 1 ? '' : 's'} · keep clicking`, done: 'Finish ×', undo: 'Undo ↶', undone: 'Last change undone', empty: 'Nothing to undo'}
  };
  chrome.storage.local.get('rastaLanguage').then(v => { lang = v.rastaLanguage === 'en' ? 'en' : 'fa'; refreshLanguage(); });
  chrome.storage.onChanged.addListener((changes, area) => { if (area === 'local' && changes.rastaLanguage) { lang = changes.rastaLanguage.newValue === 'en' ? 'en' : 'fa'; refreshLanguage(); } });
  function refreshLanguage() { if (host) host.style.direction = lang === 'fa' ? 'rtl' : 'ltr'; if (doneButton) doneButton.textContent = messages[lang].done; if (undoButton) undoButton.textContent = messages[lang].undo; if (label) label.textContent = messages[lang].hover; }
  const style = document.createElement('style');
  style.id = STYLE_ID;
  style.textContent = `
    [${MARK}="true"] { direction: rtl !important; text-align: right !important; unicode-bidi: isolate !important; }
    [${MARK}="true"] :is(code,pre,kbd,samp,[dir="ltr"]) { direction: ltr !important; unicode-bidi: isolate !important; }
    .rasta-hover-target { outline: 2px solid #6559e8 !important; outline-offset: 3px !important; cursor: crosshair !important; }
  `;
  // At document_start the root can still be absent. Never abort the entire picker.
  if (document.documentElement) (document.head || document.documentElement).appendChild(style);
  else document.addEventListener('DOMContentLoaded', () => (document.head || document.documentElement)?.appendChild(style), {once:true});

  function eligible(el) {
    if (!(el instanceof HTMLElement) || el === host || host?.contains(el)) return false;
    if (el.matches('html,body,script,style,noscript,svg,canvas,iframe,button,input,textarea,select,a,[role="button"],[role="link"]')) return false;
    const rect = el.getBoundingClientRect();
    if (!rect.width || !rect.height) return false;
    return !!el.textContent?.trim();
  }
  function findTarget(event) {
    const path = event.composedPath();
    const origin = path.find(n => n instanceof HTMLElement && !host?.contains(n));
    if (!origin || origin.closest('button,input,textarea,select,[role="button"]')) return null;
    let blocks = path.filter(n => n instanceof HTMLElement && n.matches?.(BLOCKS) && eligible(n));
    // A previously aligned ancestor wins: clicking inside it reliably restores it.
    // Hold Alt to deliberately target a larger parent instead.
    if (!event.altKey) { const marked = blocks.find(n => n.getAttribute(MARK) === 'true'); if (marked) return marked; }
    return blocks[event.altKey ? 1 : 0] || blocks[0] || (eligible(origin) ? origin : null);
  }
  function markHover(el) {
    if (hovered === el) return;
    hovered?.classList.remove('rasta-hover-target');
    hovered = el;
    hovered?.classList.add('rasta-hover-target');
    if (label) label.textContent = el ? `${messages[lang].select}: ${el.tagName.toLowerCase()} · ${el.getAttribute(MARK) === 'true' ? messages[lang].restore : messages[lang].align}` : messages[lang].hover;
  }
  let hoverFrame = 0;
  function onMove(event) {
    if (host?.contains(event.target) || hoverFrame) return;
    const path = event.composedPath();
    const altKey = event.altKey;
    hoverFrame = requestAnimationFrame(() => { hoverFrame = 0; if (picking) markHover(findTarget({composedPath: () => path, altKey})); });
  }
  function onClick(event) {
    if (host?.contains(event.target)) return;
    const target = findTarget(event);
    if (!target) return;
    event.preventDefault(); event.stopImmediatePropagation();
    history.push({target, previous: target.getAttribute(MARK)});
    if (target.getAttribute(MARK) === 'true') target.removeAttribute(MARK);
    else target.setAttribute(MARK, 'true');
    count = document.querySelectorAll(`[${MARK}="true"]`).length;
    markHover(null);
    if (label) label.textContent = messages[lang].completed(count);
  }
  function undo() {
    let entry;
    while (history.length && !entry) { const next = history.pop(); if (next.target.isConnected) entry = next; }
    if (entry) { if (entry.previous === null) entry.target.removeAttribute(MARK); else entry.target.setAttribute(MARK, entry.previous); }
    count = document.querySelectorAll(`[${MARK}="true"]`).length;
    markHover(null); if (label) label.textContent = messages[lang][entry ? 'undone' : 'empty'];
    return {picking, count, undone: !!entry};
  }
  function reset() { document.querySelectorAll(`[${MARK}="true"]`).forEach(el => el.removeAttribute(MARK)); history = []; count = 0; markHover(null); return {picking, count}; }
  function onKey(event) { if (event.key === 'Escape') { event.preventDefault(); stop(); } else if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && !event.shiftKey && !event.altKey && !event.target.closest?.('input,textarea,[contenteditable], [role="textbox"]')) { event.preventDefault(); event.stopImmediatePropagation(); undo(); } }
  function stop() {
    if (!picking) return;
    picking = false; markHover(null);
    if (hoverFrame) cancelAnimationFrame(hoverFrame); hoverFrame = 0;
    document.removeEventListener('pointermove', onMove, true);
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('keydown', onKey, true);
    host?.remove(); host = null; label = null; doneButton = null; undoButton = null;
  }
  function start() {
    if (picking) return;
    picking = true;
    host = document.createElement('div');
    host.setAttribute('data-rasta-ui', '');
    host.style.cssText = `all:initial;position:fixed;z-index:2147483647;top:18px;left:18px;direction:${lang === 'fa' ? 'rtl' : 'ltr'};`;
    const shadow = host.attachShadow({mode:'closed'});
    const bar = document.createElement('div');
    bar.style.cssText = 'display:flex;align-items:center;gap:12px;padding:10px 13px;background:#21213b;color:white;border:1px solid #8278ff;border-radius:13px;box-shadow:0 10px 35px #0005;font:13px/1.6 Tahoma,Arial,sans-serif;';
    label = document.createElement('span'); label.textContent = messages[lang].hover;
    const done = document.createElement('button'); done.type = 'button'; done.textContent = messages[lang].done; doneButton = done;
    done.style.cssText = 'font:inherit;color:white;background:#6559e8;border:0;border-radius:8px;padding:5px 10px;cursor:pointer;white-space:nowrap';
    done.addEventListener('click', stop);
    const undoBtn = document.createElement('button'); undoBtn.type = 'button'; undoBtn.textContent = messages[lang].undo; undoButton = undoBtn;
    undoBtn.style.cssText = 'font:inherit;color:white;background:#484667;border:0;border-radius:8px;padding:5px 10px;cursor:pointer;white-space:nowrap';
    undoBtn.addEventListener('click', undo);
    bar.append(label, undoBtn, done); shadow.append(bar); document.documentElement.append(host);
    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('click', onClick, true);
    document.addEventListener('keydown', onKey, true);
  }
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === 'RASTA_TOGGLE') { picking ? stop() : start(); sendResponse({picking, count: document.querySelectorAll(`[${MARK}="true"]`).length}); }
    if (msg.type === 'RASTA_STATUS') sendResponse({picking, count: document.querySelectorAll(`[${MARK}="true"]`).length});
    if (msg.type === 'RASTA_UNDO') sendResponse(undo());
    if (msg.type === 'RASTA_RESET') sendResponse(reset());
    return false;
  });
})();
