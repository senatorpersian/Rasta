// Keep local UI responsive even if Chrome rejects messages to a restricted tab.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const toggle = $('toggle'), reset = $('reset'), undo = $('undo');
  const status = $('status'), language = $('language'), theme = $('theme');
  const text = {
    fa: {tagline:'هر متن، در جای درست خودش.', eyebrow:'ابزار انتخاب دقیق', title:'بخشی را که می‌خواهید راست‌چین کنید.', description:'انتخابگر را روشن کنید، روی متن موردنظر بروید و کلیک کنید. برای انتخاب بخش بزرگ‌تر، Alt را نگه دارید.', hint:'روی همان بخش دوباره کلیک کنید تا بازگردد. Esc خروج · Alt + Shift + R انتخابگر · Alt + Shift + Z واگرد.', start:'شروع انتخاب متن', finish:'پایان انتخاب', reset:'بازگردانی همهٔ بخش‌های این صفحه', undo:'واگرد آخرین تغییر ↶', creator:'ساختهٔ', dark:'☾ حالت تیره', light:'☀ حالت روشن', ready:'برای شروع، دکمهٔ بالا را بزنید.', count:n=>`${n} بخش در این صفحه راست‌چین شده است.`, unavailable:'دسترسی به این برگه ممکن نیست. در یک وب‌سایت معمولی امتحان کنید.', failed:'ارتباط با صفحه برقرار نشد؛ صفحه را بازخوانی کنید.'},
    en: {tagline:'Every passage in its right place.', eyebrow:'PRECISE SELECTION', title:'Right-align only what you choose.', description:'Turn on the picker, hover over a passage and click. Hold Alt to select a larger block.', hint:'Click the same section again to restore it. Esc exits · Alt + Shift + R picker · Alt + Shift + Z undo.', start:'Start selecting text', finish:'Finish selection', reset:'Reset all sections on this page', undo:'Undo last change ↶', creator:'Created by', dark:'☾ Dark mode', light:'☀ Light mode', ready:'Click the button above to start.', count:n=>`${n} section${n===1?'':'s'} right-aligned on this page.`, unavailable:'This tab does not allow extensions. Try a regular website.', failed:'Could not reach this page. Reload it and try again.'}
  };
  let lang = 'fa', dark = false, state = null, busy = false;
  let tabId = null;
  const t = () => text[lang];
  const setStatus = message => { status.textContent = message; };
  function updateState(data) {
    state = data;
    toggle.innerHTML = (data.picking ? t().finish : t().start) + ' <span>' + (data.picking ? '×' : '←') + '</span>';
    setStatus(t().count(data.count));
    reset.disabled = !data.count;
    undo.disabled = !data.count;
    reset.style.opacity = data.count ? '1' : '.5';
    undo.style.opacity = data.count ? '1' : '.5';
  }
  function updateTheme() {
    document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    theme.textContent = dark ? t().light : t().dark;
    theme.setAttribute('aria-pressed', String(dark));
  }
  function updateLanguage() {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'fa' ? 'rtl' : 'ltr';
    document.querySelector('header p').textContent = t().tagline;
    document.querySelector('.eyebrow').textContent = t().eyebrow;
    document.querySelector('h2').textContent = t().title;
    document.querySelector('.card p').textContent = t().description;
    document.querySelector('.hint p').textContent = t().hint;
    document.querySelector('.credit').firstChild.textContent = t().creator + ' ';
    reset.textContent = t().reset;
    undo.textContent = t().undo;
    language.textContent = lang === 'fa' ? 'English' : 'فارسی';
    updateTheme();
    if (state) updateState(state); else setStatus(t().ready);
  }
  // Local controls are registered FIRST, independently of the current tab.
  theme.addEventListener('click', () => {
    dark = !dark; updateTheme();
    try { localStorage.setItem('rasta-theme', dark ? 'dark' : 'light'); } catch (_) {}
  });
  language.addEventListener('click', () => {
    lang = lang === 'fa' ? 'en' : 'fa'; updateLanguage();
    try { chrome.storage.local.set({rastaLanguage:lang}).catch(() => {}); } catch (_) {}
  });
  try { dark = (localStorage.getItem('rasta-theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')) === 'dark'; } catch (_) {}
  updateLanguage();
  try { chrome.storage.local.get('rastaLanguage').then(value => { if (value.rastaLanguage === 'en') { lang = 'en'; updateLanguage(); } }).catch(() => {}); } catch (_) {}

  const timeout = (promise, ms) => Promise.race([promise, new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), ms))]);
  async function getTab() {
    if (tabId) return tabId;
    const [tab] = await timeout(chrome.tabs.query({active:true,currentWindow:true}), 2000);
    tabId = tab && tab.id;
    if (!tabId) throw new Error('no tab');
    return tabId;
  }
  async function command(type) {
    const id = await getTab();
    try { return await timeout(chrome.tabs.sendMessage(id, {type}, {frameId:0}), 900); }
    catch (_) {
      // On-demand injection handles pages opened before the extension was installed.
      await timeout(chrome.scripting.executeScript({target:{tabId:id,frameIds:[0]}, files:['content.js']}), 2200);
      return await timeout(chrome.tabs.sendMessage(id, {type}, {frameId:0}), 1200);
    }
  }
  async function act(type) {
    if (busy) return;
    busy = true;
    try { const result = await command(type); if (result) { updateState(result); if (type === 'RASTA_TOGGLE') window.close(); } }
    catch (error) { setStatus(error.message === 'no tab' ? t().unavailable : t().failed); }
    finally { busy = false; }
  }
  toggle.addEventListener('click', () => act('RASTA_TOGGLE'));
  reset.addEventListener('click', () => act('RASTA_RESET'));
  undo.addEventListener('click', () => act('RASTA_UNDO'));
  // No startup request: never hold the popup hostage while examining a page.
})();
